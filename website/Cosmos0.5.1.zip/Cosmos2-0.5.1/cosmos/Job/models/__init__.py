#from cosmos import session
#from cosmos.config import settings
#import django.db.models

#from jobattempt import JobAttempt
#if settings['DRM'] == 'local':
#    from jobmanager_local import JobManager
#elif settings['DRM'] == 'Native_LSF':
#    from jobmanager_lsf import JobManager
#else:
#    from jobmanager_drmaa import JobManager
#__all__ = ['JobAttempt', 'JobManager']
