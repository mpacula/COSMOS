.. _faq:

Cosmos FAQ
==========

This is a list of Frequently Asked Questions about Cosmos.  Feel free to
suggest new entries!

Why is my job failing with `Execution Halted`
   You probably didn't request enough resources.  If Drmaa returns WasAborted=True, then that's generally
   the case.